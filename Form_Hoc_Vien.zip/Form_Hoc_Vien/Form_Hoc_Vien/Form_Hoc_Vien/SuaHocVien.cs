﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Hoc_Vien
{
    public partial class SuaHocVien : Form
    {
        private int maHocVien;
        public SuaHocVien(int maHocVien)
        {
            InitializeComponent();
            loadcbbLop();
            this.maHocVien = maHocVien;
            loadForm();
        }
        private void loadForm()
        {            
            string strQuery = "SELECT * FROM HocVien WHERE MaHocVien=@maHocVien";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@maHocVien", maHocVien);
            DataRow hocVien = database.Query(strQuery, parameters).Rows[0];
            //Nạp các thông tin lấy được lên form
            tboMaHocVien.Text = hocVien["MaHocVien"].ToString();
            tboHo.Text = hocVien["Ho"].ToString();
            tboTen.Text = hocVien["Ten"].ToString();
            dateTimePicker1.Value = DateTime.Parse(hocVien["NgaySinh"].ToString());
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (hocVien["GioiTinh"].ToString() == item.Text)
                {
                    item.Checked = true;
                }
            }
            tboDiaChi.Text = hocVien["DiaChi"].ToString();
            tboDienThoai.Text = hocVien["DienThoai"].ToString();
            tboEmail.Text = hocVien["Email"].ToString();
            dtpNgayNhapHoc.Value = DateTime.Parse(hocVien["NgayNhapHoc"].ToString());
            cbbLop.SelectedItem = database.LayTenLop(hocVien["MaLop"].ToString());           
        }
        private void loadcbbLop()
        {

            cbbLop.DisplayMember = "TenLop";
            cbbLop.ValueMember = "MaLop";
            cbbLop.DataSource = database.Query("select * from Lop", new Dictionary<string, object>());
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string query = "EXEC spSuaHocVien @maHocVien,@ho ,@ten ,@ngaySinh ,@gioiTinh,@diaChi ,@dienThoai  ,@email ,@ngayNhapHoc,@maLop";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@maHocVien", tboMaHocVien.Text);
            parameters.Add("@ho", tboHo.Text);
            parameters.Add("@ten", tboTen.Text);
            parameters.Add("@ngaySinh", dateTimePicker1.Value);
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (item.Checked)
                {
                    parameters.Add("@gioiTinh", item.Text);
                }
            }
            parameters.Add("@diaChi", tboDiaChi.Text);
            parameters.Add("@dienThoai", tboDienThoai.Text);
            parameters.Add("@email", tboEmail.Text);
            parameters.Add("@ngayNhapHoc", dtpNgayNhapHoc.Value);
            parameters.Add("@maLop", database.LayMaLop(cbbLop.Text));
            try
            {
                database.Execute(query, parameters);
                
                
            }
            catch (Exception ex)
            {
                if (ex.Message == "Trung dien thoai")
                    eprError.SetError(tboDienThoai, ex.Message);
                if (ex.Message == "Trung email")
                    eprError.SetError(tboEmail, ex.Message);               
                MessageBox.Show(ex.Message, "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
            Form1 frm1 = new Form1();
            frm1.Form1_Load();
            this.Close();
        }

        private void SuaHocVien_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tboDiaChi.Clear();
            tboDienThoai.Clear();
            tboEmail.Clear();
            tboHo.Clear();
            tboMaHocVien.Clear();
            tboTen.Clear();
            dateTimePicker1.Value = DateTime.Today;
            dtpNgayNhapHoc.Value = DateTime.Today;
        }
    }
}
