﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Hoc_Vien
{
    public partial class ThemHocVien : Form
    {
        public ThemHocVien()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
            string query = "EXEC spThemHocVien @ho ,@ten ,@ngaySinh ,@gioiTinh,@diaChi ,@dienThoai  ,@email ,@ngayNhapHoc,@maLop";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@ho", tboHo.Text);
            parameters.Add("@ten", tboTen.Text);
            parameters.Add("@ngaySinh", dateTimePicker1.Value);
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (item.Checked)
                {
                    parameters.Add("@gioiTinh", item.Text);
                }
            }
            parameters.Add("@diaChi", tboDiaChi.Text);
            parameters.Add("@dienThoai", tboDienThoai.Text);
            parameters.Add("@email", tboEmail.Text);
            parameters.Add("@ngayNhapHoc", dtpNgayNhapHoc.Value);
            parameters.Add("@maLop", database.LayMaLop(cbbLop.Text));
            try
            {
                database.Execute(query, parameters);
                loadDgvNgoaiNgu();
                lblStatus.Text = "Thông báo : Thêm dữ liêu thành công";
            }
            catch (Exception ex)
            {
                if (ex.Message == "Trung dien thoai")
                    eprError.SetError(tboDienThoai, ex.Message);
                if (ex.Message == "Trung email")
                    eprError.SetError(tboEmail, ex.Message);
                lblStatus.Text = "Thông báo: " + ex.Message;
                MessageBox.Show(ex.Message, "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string strCommand = "EXEC spXoaHoSo @maHoSo";
            parameters = new Dictionary<string, object>();
            parameters.Add("@maHoSo", tboMaHoSo.Text);
            try
            {
                database.Execute(strCommand, parameters);
                loadDgvNgoaiNgu();                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Bao loi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Thông Báo: " + ex.Message;
            }
        }   
        private void button1_Click(object sender, EventArgs e)
        {
            HoSo hs = new HoSo();
            hs.Show();
        }
        private void loadDgvNgoaiNgu()
        {
            string strQuery = "SELECT * FROM HoSo";
            DataTable table = database.Query(strQuery, new Dictionary<string, object>());
            dtgvHoSo.DataSource = table;
            string Query = "SELECT * FROM HocVien";
            DataTable tb = database.Query(Query, new Dictionary<string, object>());
            dtgvHocVien.DataSource = tb;
        }
        private void ThemHocVien_Load(object sender, EventArgs e)
        {
            loadDgvNgoaiNgu();
            loadcbbLop();
            textBox1.Text = database.LayMaLop(cbbLop.Text).ToString();
        }
        private void loadcbbLop()
        {
            
            cbbLop.DisplayMember = "TenLop";
            cbbLop.ValueMember = "MaLop";
            cbbLop.DataSource = database.Query("select * from Lop",new Dictionary<string, object>());
        }    
        private void button2_Click_1(object sender, EventArgs e)
        {
            
            string query = "EXEC spThemHoSo @ho ,@ten ,@ngaySinh ,@gioiTinh,@diaChi ,@dienThoai  ,@email ";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@ho", tboHo.Text);
            parameters.Add("@ten", tboTen.Text);
            parameters.Add("@ngaySinh", dateTimePicker1.Value);
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (item.Checked)
                {
                    parameters.Add("@gioiTinh", item.Text);
                }
            }
            parameters.Add("@diaChi", tboDiaChi.Text);
            parameters.Add("@dienThoai", tboDienThoai.Text);
            parameters.Add("@email", tboEmail.Text);
            try
            {
                database.Execute(query, parameters);
                loadDgvNgoaiNgu();
                lblStatus.Text = "Thông báo : Tro lai thành công";
            }
            catch (Exception ex)
            {
                if (ex.Message == "Trung dien thoai")
                    eprError.SetError(tboDienThoai, ex.Message);
                if (ex.Message == "Trung email")
                    eprError.SetError(tboEmail, ex.Message);
                lblStatus.Text = "Thông báo: " + ex.Message;
                MessageBox.Show(ex.Message, "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string strCommand = "EXEC spXoaHocVien @maHocVien";
            parameters = new Dictionary<string, object>();
            parameters.Add("@maHocVien", database.LayMaHocVien(tboDienThoai.Text));
            try
            {
                database.Execute(strCommand, parameters);
                loadDgvNgoaiNgu();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Bao loi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Thông Báo: " + ex.Message;
            }
        }

        private void dtgvHocVien_RowEnter(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtgvHoSo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
                int i = dtgvHoSo.CurrentRow.Index;
                tboMaHoSo.Text = dtgvHoSo.Rows[i].Cells["ColMaHoSo"].Value.ToString();
                tboHo.Text = dtgvHoSo.Rows[i].Cells["ColHo"].Value.ToString();
                tboTen.Text = dtgvHoSo.Rows[i].Cells["ColTen"].Value.ToString();
                dateTimePicker1.Text = dtgvHoSo.Rows[i].Cells["ColNgaySinh"].Value.ToString();
                foreach (RadioButton item in groupBox3.Controls)
                {
                    if (dtgvHoSo.Rows[i].Cells["ColGioiTinh"].Value.ToString() == item.Text)
                    {
                        item.Checked = true;
                    }
                }
                tboDiaChi.Text = dtgvHoSo.Rows[i].Cells["ColDiaChi"].Value.ToString();
                tboDienThoai.Text = dtgvHoSo.Rows[i].Cells["ColDienThoai"].Value.ToString();
                tboEmail.Text = dtgvHoSo.Rows[i].Cells["ColEmail"].Value.ToString();
            
        }
    }
}
