﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Hoc_Vien
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loadcbbLop();
            loaddtgvHocVien();
        }
        private void butSua_Click(object sender, EventArgs e)
        {

            int maHocVien = (int)dtgvHocVien.CurrentRow.Cells["ColMaHocVien"].Value;
            SuaHocVien form = new SuaHocVien(maHocVien);
            form.ShowDialog();
        }
        private void loadcbbLop()
        {

            cbLop.DisplayMember = "TenLop";
            cbLop.ValueMember = "MaLop";
            cbLop.DataSource = database.Query("select * from Lop", new Dictionary<string, object>());
        }
        private void cbbMaHocVien_CheckedChanged(object sender, EventArgs e)
        {
            tboMaHocVien.Enabled = cbbMaHocVien.Checked;
        }

        private void cbbHo_CheckedChanged(object sender, EventArgs e)
        {
            tboHo.Enabled = cbbHo.Checked;
        }

        private void cbbTen_CheckedChanged(object sender, EventArgs e)
        {
            tboTen.Enabled = cbbTen.Checked;
        }

        private void cbbNgaySinh_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Enabled = cbbNgaySinh.Checked;
        }


        private void cbbDienThoai_CheckedChanged(object sender, EventArgs e)
        {
            tboDienThoai.Enabled = cbbDienThoai.Checked;
        }

        private void cbbEmail_CheckedChanged(object sender, EventArgs e)
        {
            tboEmail.Enabled = cbbEmail.Checked;
        }

        private void cbbNgayNhapHoc_CheckedChanged(object sender, EventArgs e)
        {
            dtpNgayNhapHoc.Enabled = cbbNgayNhapHoc.Checked;
        }

        private void cbbLop_CheckedChanged(object sender, EventArgs e)
        {
            cbLop.Enabled = cbbLop.Checked;
        }

        private void loaddtgvHocVien()
        {
            string strQuery = "SELECT *from HocVien WHERE 1=1";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (cbbMaHocVien.Checked)
            {
                strQuery += " AND MaHocVien=@maHocVien";
                parameters.Add("@maHocVien", int.Parse(tboMaHocVien.Text));
            }
            if (cbbHo.Checked)
            {
                strQuery += " AND Ho LIKE '%' + @ho + '%'";
                parameters.Add("@ho", tboHo.Text);
            }
            if (cbbTen.Checked)
            {
                strQuery += " AND Ten LIKE '%' + @ten + '%'";
                parameters.Add("@ten", tboTen.Text);
            }
            if (cbbNgaySinh.Checked)
            {
                strQuery += " AND NgaySinh>=@ngaySinhTu";
                parameters.Add("@ngaySinhTu", dateTimePicker1.Value.Date);
            }
            if (cbbGioiTinh.Checked)
            {
                foreach (RadioButton item in groupBox3.Controls)
                {
                    if (item.Checked == true)
                    {
                        strQuery += " AND GioiTinh=@gioiTinh";
                        parameters.Add("@gioiTinh", item.Text);
                    }
                }
            }
            if (cbbDiaChi.Checked)
            {
                strQuery += " AND DiaChi LIKE '%' + @diaChi + '%'";
                parameters.Add("@diaChi", tboDiaChi.Text);
            }
            if (cbbDienThoai.Checked)
            {
                strQuery += " AND DienThoai LIKE '%' + @dienThoai + '%'";
                parameters.Add("@dienThoai", tboDienThoai.Text);
            }
            if (cbbEmail.Checked)
            {
                strQuery += " AND Email LIKE '%' + @email + '%'";
                parameters.Add("@email", tboEmail.Text);
            }
            if (cbbNgayNhapHoc.Checked)
            {
                strQuery += " AND NgayNhapHoc = @ngayNhapHoc";
                parameters.Add("@ngayNhapHoc", dtpNgayNhapHoc.Value.ToString());
            }
            if (cbbLop.Checked)
            {
                strQuery += " AND MaLop = @maLop";
                parameters.Add("@maLop", database.LayMaLop(cbLop.Text));
            }
            dtgvHocVien.DataSource = database.Query(strQuery, parameters);
        }
        private void butThem_Click_1(object sender, EventArgs e)
        {
            ThemHocVien Them = new ThemHocVien();
            Them.ShowDialog();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            loaddtgvHocVien();
        }

        private void chbNgaySinh_CheckedChanged(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColNgaySinh"].Visible = chbNgaySinh.Checked;
        }

        private void chbGioiTinh_CheckedChanged(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColGioiTinh"].Visible = chbGioiTinh.Checked;
        }

        private void chbDiaChi_CheckedChanged(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColDiaChi"].Visible = chbDiaChi.Checked;
        }

        private void chbDienThoai_CheckedChanged_1(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColDienThoai"].Visible = chbDienThoai.Checked;
        }

        private void chbEmail_CheckedChanged_1(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColEmail"].Visible = chbEmail.Checked;
        }

        private void chbNgayNhapHoc_CheckedChanged(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColNgayNhapHoc"].Visible = chbNgayNhapHoc.Checked;
        }

        private void chbLop_CheckedChanged_1(object sender, EventArgs e)
        {
            dtgvHocVien.Columns["ColLop"].Visible = chbLop.Checked;
        }

        public void Form1_Load()
        {
            loadcbbLop();
            loaddtgvHocVien();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tboDiaChi.Clear();
            tboDienThoai.Clear();
            tboEmail.Clear();
            tboHo.Clear();
            tboMaHocVien.Clear();
            tboTen.Clear();           
            dateTimePicker1.Value = DateTime.Today;
            dtpNgayNhapHoc.Value = DateTime.Today;
        }

        private void cbbDiaChi_CheckedChanged(object sender, EventArgs e)
        {
            tboDiaChi.Enabled = cbbDiaChi.Checked;
        }

        private void butXoa_Click(object sender, EventArgs e)
        {
            string strCommand = "EXEC spXoaHocVien @maHoSo";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@maHocVien", dtgvHocVien.CurrentRow.Cells["ColMaHocVien"].Value.ToString());
            try
            {
                database.Execute(strCommand, parameters);
                loaddtgvHocVien();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Bao loi", MessageBoxButtons.OK, MessageBoxIcon.Error);               
            }
        }
    }
}