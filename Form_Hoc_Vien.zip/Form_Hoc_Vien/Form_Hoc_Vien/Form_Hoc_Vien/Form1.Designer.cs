﻿namespace Form_Hoc_Vien
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.chbLop = new System.Windows.Forms.CheckBox();
            this.chbNgayNhapHoc = new System.Windows.Forms.CheckBox();
            this.chbEmail = new System.Windows.Forms.CheckBox();
            this.chbDienThoai = new System.Windows.Forms.CheckBox();
            this.chbDiaChi = new System.Windows.Forms.CheckBox();
            this.chbGioiTinh = new System.Windows.Forms.CheckBox();
            this.chbNgaySinh = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.butThem = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.butSua = new System.Windows.Forms.Button();
            this.butXoa = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbbLop = new System.Windows.Forms.CheckBox();
            this.cbbNgayNhapHoc = new System.Windows.Forms.CheckBox();
            this.cbbEmail = new System.Windows.Forms.CheckBox();
            this.cbbDienThoai = new System.Windows.Forms.CheckBox();
            this.cbbDiaChi = new System.Windows.Forms.CheckBox();
            this.cbbGioiTinh = new System.Windows.Forms.CheckBox();
            this.cbbNgaySinh = new System.Windows.Forms.CheckBox();
            this.cbbTen = new System.Windows.Forms.CheckBox();
            this.cbbHo = new System.Windows.Forms.CheckBox();
            this.cbbMaHocVien = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tboEmail = new System.Windows.Forms.TextBox();
            this.tboDienThoai = new System.Windows.Forms.TextBox();
            this.tboDiaChi = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tboMaHocVien = new System.Windows.Forms.TextBox();
            this.tboTen = new System.Windows.Forms.TextBox();
            this.tboHo = new System.Windows.Forms.TextBox();
            this.cbLop = new System.Windows.Forms.ComboBox();
            this.dtpNgayNhapHoc = new System.Windows.Forms.DateTimePicker();
            this.btnTim = new System.Windows.Forms.Button();
            this.dtgvHocVien = new System.Windows.Forms.DataGridView();
            this.ColMaHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColHo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datColTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColNgaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColGioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDienThoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColNgayNhaphoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHocVien)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.chbLop);
            this.groupBox6.Controls.Add(this.chbNgayNhapHoc);
            this.groupBox6.Controls.Add(this.chbEmail);
            this.groupBox6.Controls.Add(this.chbDienThoai);
            this.groupBox6.Controls.Add(this.chbDiaChi);
            this.groupBox6.Controls.Add(this.chbGioiTinh);
            this.groupBox6.Controls.Add(this.chbNgaySinh);
            this.groupBox6.Location = new System.Drawing.Point(406, 511);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(993, 58);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thông tin hiện thị";
            // 
            // chbLop
            // 
            this.chbLop.AutoSize = true;
            this.chbLop.Checked = true;
            this.chbLop.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbLop.Location = new System.Drawing.Point(662, 21);
            this.chbLop.Name = "chbLop";
            this.chbLop.Size = new System.Drawing.Size(54, 21);
            this.chbLop.TabIndex = 56;
            this.chbLop.Text = "Lớp";
            this.chbLop.UseVisualStyleBackColor = true;
            this.chbLop.CheckedChanged += new System.EventHandler(this.chbLop_CheckedChanged_1);
            // 
            // chbNgayNhapHoc
            // 
            this.chbNgayNhapHoc.AutoSize = true;
            this.chbNgayNhapHoc.Checked = true;
            this.chbNgayNhapHoc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbNgayNhapHoc.Location = new System.Drawing.Point(513, 21);
            this.chbNgayNhapHoc.Name = "chbNgayNhapHoc";
            this.chbNgayNhapHoc.Size = new System.Drawing.Size(126, 21);
            this.chbNgayNhapHoc.TabIndex = 4;
            this.chbNgayNhapHoc.Text = "Ngày nhập học";
            this.chbNgayNhapHoc.UseVisualStyleBackColor = true;
            this.chbNgayNhapHoc.CheckedChanged += new System.EventHandler(this.chbNgayNhapHoc_CheckedChanged);
            // 
            // chbEmail
            // 
            this.chbEmail.AutoSize = true;
            this.chbEmail.Checked = true;
            this.chbEmail.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbEmail.Location = new System.Drawing.Point(426, 22);
            this.chbEmail.Name = "chbEmail";
            this.chbEmail.Size = new System.Drawing.Size(64, 21);
            this.chbEmail.TabIndex = 3;
            this.chbEmail.Text = "Email";
            this.chbEmail.UseVisualStyleBackColor = true;
            this.chbEmail.CheckedChanged += new System.EventHandler(this.chbEmail_CheckedChanged_1);
            // 
            // chbDienThoai
            // 
            this.chbDienThoai.AutoSize = true;
            this.chbDienThoai.Checked = true;
            this.chbDienThoai.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbDienThoai.Location = new System.Drawing.Point(303, 22);
            this.chbDienThoai.Name = "chbDienThoai";
            this.chbDienThoai.Size = new System.Drawing.Size(94, 21);
            this.chbDienThoai.TabIndex = 1;
            this.chbDienThoai.Text = "Điện thoại";
            this.chbDienThoai.UseVisualStyleBackColor = true;
            this.chbDienThoai.CheckedChanged += new System.EventHandler(this.chbDienThoai_CheckedChanged_1);
            // 
            // chbDiaChi
            // 
            this.chbDiaChi.AutoSize = true;
            this.chbDiaChi.Checked = true;
            this.chbDiaChi.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbDiaChi.Location = new System.Drawing.Point(204, 22);
            this.chbDiaChi.Name = "chbDiaChi";
            this.chbDiaChi.Size = new System.Drawing.Size(73, 21);
            this.chbDiaChi.TabIndex = 2;
            this.chbDiaChi.Text = "Địa chỉ";
            this.chbDiaChi.UseVisualStyleBackColor = true;
            this.chbDiaChi.CheckedChanged += new System.EventHandler(this.chbDiaChi_CheckedChanged);
            // 
            // chbGioiTinh
            // 
            this.chbGioiTinh.AutoSize = true;
            this.chbGioiTinh.Checked = true;
            this.chbGioiTinh.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbGioiTinh.Location = new System.Drawing.Point(116, 22);
            this.chbGioiTinh.Name = "chbGioiTinh";
            this.chbGioiTinh.Size = new System.Drawing.Size(82, 21);
            this.chbGioiTinh.TabIndex = 0;
            this.chbGioiTinh.Text = "Giới tính";
            this.chbGioiTinh.UseVisualStyleBackColor = true;
            this.chbGioiTinh.CheckedChanged += new System.EventHandler(this.chbGioiTinh_CheckedChanged);
            // 
            // chbNgaySinh
            // 
            this.chbNgaySinh.AutoSize = true;
            this.chbNgaySinh.Checked = true;
            this.chbNgaySinh.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbNgaySinh.Location = new System.Drawing.Point(17, 22);
            this.chbNgaySinh.Name = "chbNgaySinh";
            this.chbNgaySinh.Size = new System.Drawing.Size(93, 21);
            this.chbNgaySinh.TabIndex = 0;
            this.chbNgaySinh.Text = "Ngày sinh";
            this.chbNgaySinh.UseVisualStyleBackColor = true;
            this.chbNgaySinh.CheckedChanged += new System.EventHandler(this.chbNgaySinh_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(520, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(352, 38);
            this.label1.TabIndex = 8;
            this.label1.Text = "QUẢN LÝ HỌC VIÊN";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.butThem);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.butSua);
            this.groupBox2.Controls.Add(this.butXoa);
            this.groupBox2.Location = new System.Drawing.Point(406, 85);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(993, 95);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cập nhật";
            // 
            // butThem
            // 
            this.butThem.Location = new System.Drawing.Point(71, 41);
            this.butThem.Margin = new System.Windows.Forms.Padding(4);
            this.butThem.Name = "butThem";
            this.butThem.Size = new System.Drawing.Size(100, 28);
            this.butThem.TabIndex = 3;
            this.butThem.Text = "Thêm";
            this.butThem.UseVisualStyleBackColor = true;
            this.butThem.Click += new System.EventHandler(this.butThem_Click_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(472, 36);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 31);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(233, 36);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 31);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Form_Hoc_Vien.Properties.Resources.add;
            this.pictureBox1.Location = new System.Drawing.Point(29, 38);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // butSua
            // 
            this.butSua.Location = new System.Drawing.Point(275, 39);
            this.butSua.Margin = new System.Windows.Forms.Padding(4);
            this.butSua.Name = "butSua";
            this.butSua.Size = new System.Drawing.Size(100, 28);
            this.butSua.TabIndex = 1;
            this.butSua.Text = "Sửa";
            this.butSua.UseVisualStyleBackColor = true;
            this.butSua.Click += new System.EventHandler(this.butSua_Click);
            // 
            // butXoa
            // 
            this.butXoa.Location = new System.Drawing.Point(513, 38);
            this.butXoa.Margin = new System.Windows.Forms.Padding(4);
            this.butXoa.Name = "butXoa";
            this.butXoa.Size = new System.Drawing.Size(100, 28);
            this.butXoa.TabIndex = 0;
            this.butXoa.Text = "Xoá";
            this.butXoa.UseVisualStyleBackColor = true;
            this.butXoa.Click += new System.EventHandler(this.butXoa_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbbLop);
            this.groupBox1.Controls.Add(this.cbbNgayNhapHoc);
            this.groupBox1.Controls.Add(this.cbbEmail);
            this.groupBox1.Controls.Add(this.cbbDienThoai);
            this.groupBox1.Controls.Add(this.cbbDiaChi);
            this.groupBox1.Controls.Add(this.cbbGioiTinh);
            this.groupBox1.Controls.Add(this.cbbNgaySinh);
            this.groupBox1.Controls.Add(this.cbbTen);
            this.groupBox1.Controls.Add(this.cbbHo);
            this.groupBox1.Controls.Add(this.cbbMaHocVien);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.tboEmail);
            this.groupBox1.Controls.Add(this.tboDienThoai);
            this.groupBox1.Controls.Add(this.tboDiaChi);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.tboMaHocVien);
            this.groupBox1.Controls.Add(this.tboTen);
            this.groupBox1.Controls.Add(this.tboHo);
            this.groupBox1.Controls.Add(this.cbLop);
            this.groupBox1.Controls.Add(this.dtpNgayNhapHoc);
            this.groupBox1.Controls.Add(this.btnTim);
            this.groupBox1.Location = new System.Drawing.Point(11, 59);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(387, 510);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm";
            // 
            // cbbLop
            // 
            this.cbbLop.AutoSize = true;
            this.cbbLop.Location = new System.Drawing.Point(10, 413);
            this.cbbLop.Name = "cbbLop";
            this.cbbLop.Size = new System.Drawing.Size(54, 21);
            this.cbbLop.TabIndex = 55;
            this.cbbLop.Text = "Lớp";
            this.cbbLop.UseVisualStyleBackColor = true;
            this.cbbLop.CheckedChanged += new System.EventHandler(this.cbbLop_CheckedChanged);
            // 
            // cbbNgayNhapHoc
            // 
            this.cbbNgayNhapHoc.AutoSize = true;
            this.cbbNgayNhapHoc.Location = new System.Drawing.Point(10, 374);
            this.cbbNgayNhapHoc.Name = "cbbNgayNhapHoc";
            this.cbbNgayNhapHoc.Size = new System.Drawing.Size(126, 21);
            this.cbbNgayNhapHoc.TabIndex = 54;
            this.cbbNgayNhapHoc.Text = "Ngày nhập học";
            this.cbbNgayNhapHoc.UseVisualStyleBackColor = true;
            this.cbbNgayNhapHoc.CheckedChanged += new System.EventHandler(this.cbbNgayNhapHoc_CheckedChanged);
            // 
            // cbbEmail
            // 
            this.cbbEmail.AutoSize = true;
            this.cbbEmail.Location = new System.Drawing.Point(10, 333);
            this.cbbEmail.Name = "cbbEmail";
            this.cbbEmail.Size = new System.Drawing.Size(64, 21);
            this.cbbEmail.TabIndex = 53;
            this.cbbEmail.Text = "Email";
            this.cbbEmail.UseVisualStyleBackColor = true;
            this.cbbEmail.CheckedChanged += new System.EventHandler(this.cbbEmail_CheckedChanged);
            // 
            // cbbDienThoai
            // 
            this.cbbDienThoai.AutoSize = true;
            this.cbbDienThoai.Location = new System.Drawing.Point(10, 292);
            this.cbbDienThoai.Name = "cbbDienThoai";
            this.cbbDienThoai.Size = new System.Drawing.Size(94, 21);
            this.cbbDienThoai.TabIndex = 52;
            this.cbbDienThoai.Text = "Điện thoại";
            this.cbbDienThoai.UseVisualStyleBackColor = true;
            this.cbbDienThoai.CheckedChanged += new System.EventHandler(this.cbbDienThoai_CheckedChanged);
            // 
            // cbbDiaChi
            // 
            this.cbbDiaChi.AutoSize = true;
            this.cbbDiaChi.Location = new System.Drawing.Point(10, 246);
            this.cbbDiaChi.Name = "cbbDiaChi";
            this.cbbDiaChi.Size = new System.Drawing.Size(73, 21);
            this.cbbDiaChi.TabIndex = 51;
            this.cbbDiaChi.Text = "Địa chỉ";
            this.cbbDiaChi.UseVisualStyleBackColor = true;
            this.cbbDiaChi.CheckedChanged += new System.EventHandler(this.cbbDiaChi_CheckedChanged);
            // 
            // cbbGioiTinh
            // 
            this.cbbGioiTinh.AutoSize = true;
            this.cbbGioiTinh.Location = new System.Drawing.Point(10, 209);
            this.cbbGioiTinh.Name = "cbbGioiTinh";
            this.cbbGioiTinh.Size = new System.Drawing.Size(82, 21);
            this.cbbGioiTinh.TabIndex = 50;
            this.cbbGioiTinh.Text = "Giới tính";
            this.cbbGioiTinh.UseVisualStyleBackColor = true;
            // 
            // cbbNgaySinh
            // 
            this.cbbNgaySinh.AutoSize = true;
            this.cbbNgaySinh.Location = new System.Drawing.Point(10, 162);
            this.cbbNgaySinh.Name = "cbbNgaySinh";
            this.cbbNgaySinh.Size = new System.Drawing.Size(93, 21);
            this.cbbNgaySinh.TabIndex = 49;
            this.cbbNgaySinh.Text = "Ngày sinh";
            this.cbbNgaySinh.UseVisualStyleBackColor = true;
            this.cbbNgaySinh.CheckedChanged += new System.EventHandler(this.cbbNgaySinh_CheckedChanged);
            // 
            // cbbTen
            // 
            this.cbbTen.AutoSize = true;
            this.cbbTen.Location = new System.Drawing.Point(10, 119);
            this.cbbTen.Name = "cbbTen";
            this.cbbTen.Size = new System.Drawing.Size(55, 21);
            this.cbbTen.TabIndex = 48;
            this.cbbTen.Text = "Tên";
            this.cbbTen.UseVisualStyleBackColor = true;
            this.cbbTen.CheckedChanged += new System.EventHandler(this.cbbTen_CheckedChanged);
            // 
            // cbbHo
            // 
            this.cbbHo.AutoSize = true;
            this.cbbHo.Location = new System.Drawing.Point(10, 78);
            this.cbbHo.Name = "cbbHo";
            this.cbbHo.Size = new System.Drawing.Size(52, 21);
            this.cbbHo.TabIndex = 47;
            this.cbbHo.Text = "Họ ";
            this.cbbHo.UseVisualStyleBackColor = true;
            this.cbbHo.CheckedChanged += new System.EventHandler(this.cbbHo_CheckedChanged);
            // 
            // cbbMaHocVien
            // 
            this.cbbMaHocVien.AutoSize = true;
            this.cbbMaHocVien.Location = new System.Drawing.Point(10, 35);
            this.cbbMaHocVien.Name = "cbbMaHocVien";
            this.cbbMaHocVien.Size = new System.Drawing.Size(106, 21);
            this.cbbMaHocVien.TabIndex = 46;
            this.cbbMaHocVien.Text = "Mã học viên";
            this.cbbMaHocVien.UseVisualStyleBackColor = true;
            this.cbbMaHocVien.CheckedChanged += new System.EventHandler(this.cbbMaHocVien_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(279, 475);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 28);
            this.button2.TabIndex = 44;
            this.button2.Text = "Xóa hết";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tboEmail
            // 
            this.tboEmail.Enabled = false;
            this.tboEmail.Location = new System.Drawing.Point(153, 333);
            this.tboEmail.Margin = new System.Windows.Forms.Padding(4);
            this.tboEmail.Name = "tboEmail";
            this.tboEmail.Size = new System.Drawing.Size(190, 22);
            this.tboEmail.TabIndex = 41;
            // 
            // tboDienThoai
            // 
            this.tboDienThoai.Enabled = false;
            this.tboDienThoai.Location = new System.Drawing.Point(153, 291);
            this.tboDienThoai.Margin = new System.Windows.Forms.Padding(4);
            this.tboDienThoai.Name = "tboDienThoai";
            this.tboDienThoai.Size = new System.Drawing.Size(190, 22);
            this.tboDienThoai.TabIndex = 42;
            // 
            // tboDiaChi
            // 
            this.tboDiaChi.Enabled = false;
            this.tboDiaChi.Location = new System.Drawing.Point(154, 246);
            this.tboDiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.tboDiaChi.Name = "tboDiaChi";
            this.tboDiaChi.Size = new System.Drawing.Size(189, 22);
            this.tboDiaChi.TabIndex = 43;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Location = new System.Drawing.Point(153, 196);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(189, 34);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(112, 10);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 21);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Nữ";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(28, 10);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(58, 21);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Nam";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Location = new System.Drawing.Point(154, 162);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(188, 22);
            this.dateTimePicker1.TabIndex = 39;
            // 
            // tboMaHocVien
            // 
            this.tboMaHocVien.Enabled = false;
            this.tboMaHocVien.Location = new System.Drawing.Point(153, 35);
            this.tboMaHocVien.Margin = new System.Windows.Forms.Padding(4);
            this.tboMaHocVien.Name = "tboMaHocVien";
            this.tboMaHocVien.Size = new System.Drawing.Size(188, 22);
            this.tboMaHocVien.TabIndex = 38;
            // 
            // tboTen
            // 
            this.tboTen.Enabled = false;
            this.tboTen.Location = new System.Drawing.Point(153, 119);
            this.tboTen.Margin = new System.Windows.Forms.Padding(4);
            this.tboTen.Name = "tboTen";
            this.tboTen.Size = new System.Drawing.Size(188, 22);
            this.tboTen.TabIndex = 37;
            // 
            // tboHo
            // 
            this.tboHo.Enabled = false;
            this.tboHo.Location = new System.Drawing.Point(153, 78);
            this.tboHo.Margin = new System.Windows.Forms.Padding(4);
            this.tboHo.Name = "tboHo";
            this.tboHo.Size = new System.Drawing.Size(188, 22);
            this.tboHo.TabIndex = 38;
            // 
            // cbLop
            // 
            this.cbLop.Enabled = false;
            this.cbLop.FormattingEnabled = true;
            this.cbLop.Location = new System.Drawing.Point(154, 413);
            this.cbLop.Name = "cbLop";
            this.cbLop.Size = new System.Drawing.Size(189, 24);
            this.cbLop.TabIndex = 29;
            // 
            // dtpNgayNhapHoc
            // 
            this.dtpNgayNhapHoc.Enabled = false;
            this.dtpNgayNhapHoc.Location = new System.Drawing.Point(154, 374);
            this.dtpNgayNhapHoc.Margin = new System.Windows.Forms.Padding(4);
            this.dtpNgayNhapHoc.Name = "dtpNgayNhapHoc";
            this.dtpNgayNhapHoc.Size = new System.Drawing.Size(189, 22);
            this.dtpNgayNhapHoc.TabIndex = 8;
            // 
            // btnTim
            // 
            this.btnTim.Location = new System.Drawing.Point(3, 474);
            this.btnTim.Margin = new System.Windows.Forms.Padding(4);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(100, 28);
            this.btnTim.TabIndex = 6;
            this.btnTim.Text = "Tìm kiếm";
            this.btnTim.UseVisualStyleBackColor = true;
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // dtgvHocVien
            // 
            this.dtgvHocVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvHocVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvHocVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColMaHocVien,
            this.ColHo,
            this.datColTen,
            this.ColNgaySinh,
            this.ColGioiTinh,
            this.ColDiaChi,
            this.ColDienThoai,
            this.ColEmail,
            this.ColNgayNhaphoc,
            this.ColLop});
            this.dtgvHocVien.Location = new System.Drawing.Point(406, 188);
            this.dtgvHocVien.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvHocVien.Name = "dtgvHocVien";
            this.dtgvHocVien.RowHeadersWidth = 51;
            this.dtgvHocVien.Size = new System.Drawing.Size(993, 316);
            this.dtgvHocVien.TabIndex = 56;
            // 
            // ColMaHocVien
            // 
            this.ColMaHocVien.DataPropertyName = "MaHocVien";
            this.ColMaHocVien.HeaderText = "Mã học viên";
            this.ColMaHocVien.MinimumWidth = 6;
            this.ColMaHocVien.Name = "ColMaHocVien";
            // 
            // ColHo
            // 
            this.ColHo.DataPropertyName = "Ho";
            this.ColHo.HeaderText = "Ho";
            this.ColHo.MinimumWidth = 6;
            this.ColHo.Name = "ColHo";
            // 
            // datColTen
            // 
            this.datColTen.DataPropertyName = "Ten";
            this.datColTen.HeaderText = "Ten";
            this.datColTen.MinimumWidth = 6;
            this.datColTen.Name = "datColTen";
            // 
            // ColNgaySinh
            // 
            this.ColNgaySinh.DataPropertyName = "NgaySinh";
            this.ColNgaySinh.HeaderText = "NgaySinh";
            this.ColNgaySinh.MinimumWidth = 6;
            this.ColNgaySinh.Name = "ColNgaySinh";
            // 
            // ColGioiTinh
            // 
            this.ColGioiTinh.DataPropertyName = "GioiTinh";
            this.ColGioiTinh.HeaderText = "GioiTinh";
            this.ColGioiTinh.MinimumWidth = 6;
            this.ColGioiTinh.Name = "ColGioiTinh";
            // 
            // ColDiaChi
            // 
            this.ColDiaChi.DataPropertyName = "DiaChi";
            this.ColDiaChi.HeaderText = "DiaChi";
            this.ColDiaChi.MinimumWidth = 6;
            this.ColDiaChi.Name = "ColDiaChi";
            // 
            // ColDienThoai
            // 
            this.ColDienThoai.DataPropertyName = "DienThoai";
            this.ColDienThoai.HeaderText = "DienThoai";
            this.ColDienThoai.MinimumWidth = 6;
            this.ColDienThoai.Name = "ColDienThoai";
            // 
            // ColEmail
            // 
            this.ColEmail.DataPropertyName = "Email";
            this.ColEmail.HeaderText = "Email";
            this.ColEmail.MinimumWidth = 6;
            this.ColEmail.Name = "ColEmail";
            // 
            // ColNgayNhaphoc
            // 
            this.ColNgayNhaphoc.DataPropertyName = "NgayNhapHoc";
            this.ColNgayNhaphoc.HeaderText = "Ngày nhập học";
            this.ColNgayNhaphoc.MinimumWidth = 6;
            this.ColNgayNhaphoc.Name = "ColNgayNhaphoc";
            // 
            // ColLop
            // 
            this.ColLop.DataPropertyName = "MaLop";
            this.ColLop.HeaderText = "Mã Lớp";
            this.ColLop.MinimumWidth = 6;
            this.ColLop.Name = "ColLop";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1412, 578);
            this.Controls.Add(this.dtgvHocVien);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHocVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox chbNgayNhapHoc;
        private System.Windows.Forms.CheckBox chbEmail;
        private System.Windows.Forms.CheckBox chbDienThoai;
        private System.Windows.Forms.CheckBox chbDiaChi;
        private System.Windows.Forms.CheckBox chbGioiTinh;
        private System.Windows.Forms.CheckBox chbNgaySinh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button butThem;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button butSua;
        private System.Windows.Forms.Button butXoa;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbbEmail;
        private System.Windows.Forms.CheckBox cbbDienThoai;
        private System.Windows.Forms.CheckBox cbbDiaChi;
        private System.Windows.Forms.CheckBox cbbGioiTinh;
        private System.Windows.Forms.CheckBox cbbNgaySinh;
        private System.Windows.Forms.CheckBox cbbTen;
        private System.Windows.Forms.CheckBox cbbHo;
        private System.Windows.Forms.CheckBox cbbMaHocVien;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tboEmail;
        private System.Windows.Forms.TextBox tboDienThoai;
        private System.Windows.Forms.TextBox tboDiaChi;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox tboMaHocVien;
        private System.Windows.Forms.TextBox tboTen;
        private System.Windows.Forms.TextBox tboHo;
        private System.Windows.Forms.ComboBox cbLop;
        private System.Windows.Forms.DateTimePicker dtpNgayNhapHoc;
        private System.Windows.Forms.Button btnTim;
        private System.Windows.Forms.CheckBox cbbLop;
        private System.Windows.Forms.CheckBox cbbNgayNhapHoc;
        private System.Windows.Forms.CheckBox chbLop;
        private System.Windows.Forms.DataGridView dtgvHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColMaHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColHo;
        private System.Windows.Forms.DataGridViewTextBoxColumn datColTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColNgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColGioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDiaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDienThoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColNgayNhaphoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColLop;
    }
}

