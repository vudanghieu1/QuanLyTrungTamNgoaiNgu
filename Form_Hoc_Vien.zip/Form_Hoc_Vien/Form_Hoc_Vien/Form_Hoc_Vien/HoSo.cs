﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Hoc_Vien
{
    public partial class HoSo : Form
    {
        public HoSo()
        {
            InitializeComponent();
        }
        private bool checkForm()
        {
            eprError.Clear();
            bool ketQua = true;
            if (tboTen.Text.Trim() == "")
            {
                
                eprError.SetError(tboTen, "Chưa điền ten");
                ketQua = false;
            }
            if (tboTen.Text.Length > 15)
            {
                //MessageBox.Show("Mã ngoại ngữ không đúng định dạng");
                eprError.SetError(tboTen, "Ten không đúng định dạng");
                ketQua = false;
            }
            if (tboHo.Text.Trim() == "")
            {
                //MessageBox.Show("Chưa điền tên ngoại ngữ");
                eprError.SetError(tboHo, "Chưa điền ho");
                ketQua = false;
            }
            if (tboHo.Text.Length > 30)
            {
                //MessageBox.Show("Tên ngoại ngữ không đúng định dạng");
                eprError.SetError(tboHo, "Ho không đúng định dạng");
                ketQua = false;
            }
            if (tboDienThoai.Text.Trim() == "")
            {
                //MessageBox.Show("Chưa điền tên ngoại ngữ");
                eprError.SetError(tboHo, "Chưa điền so dien thoai");
                ketQua = false;
            }
            if (tboHo.Text.Length > 10)
            {
                //MessageBox.Show("Tên ngoại ngữ không đúng định dạng");
                eprError.SetError(tboHo, "So dien thoai không đúng định dạng");
                ketQua = false;
            }
            
            if (ketQua == false)
                lblStatus.Text = "Thông báo: dữ liệu không đúng định dạng";
            return ketQua;

        }
        private void HoSo_Load(object sender, EventArgs e)
        {
            loadDgvNgoaiNgu();
        }
        private void loadDgvNgoaiNgu()
        {
                string strQuery = "SELECT * FROM HoSo";
                DataTable table = database.Query(strQuery, new Dictionary<string, object>());
                dataGridView1.DataSource = table;
                btnSua.Enabled = btnXoa.Enabled = table.Rows.Count > 0;
           
        }
        private void butThem_Click(object sender, EventArgs e)
        {
            bool ketqua = true;
            if (checkForm() == false)
                return;
            string query = "EXEC spThemHoSo @ho ,@ten ,@ngaySinh ,@gioiTinh,@diaChi ,@dienThoai  ,@email ";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@ho", tboHo.Text);
            parameters.Add("@ten", tboTen.Text);
            parameters.Add("@ngaySinh", dateTimePicker1.Value);
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (item.Checked)
                {
                    parameters.Add("@gioiTinh", item.Text);
                }
            }
            parameters.Add("@diaChi", tboDiaChi.Text);
            parameters.Add("@dienThoai", tboDienThoai.Text);
            parameters.Add("@email", tboEmail.Text);
            try
            {
                database.Execute(query, parameters);
                loadDgvNgoaiNgu();
                lblStatus.Text = "Thông báo : Thêm dữ liêu thành công";
            }
            catch(Exception ex)
            {
                if (ex.Message == "Trung dien thoai")
                    eprError.SetError(tboDienThoai, ex.Message);
                if (ex.Message == "Trung email")
                    eprError.SetError(tboEmail, ex.Message);
                lblStatus.Text = "Thông báo: " + ex.Message;
                MessageBox.Show(ex.Message, "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (checkForm() == false)
                return;
            string query = "EXEC spSuaHoSo @maHoSo,@ho ,@ten ,@ngaySinh ,@gioiTinh,@diaChi ,@dienThoai  ,@email";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@maHoSo", dataGridView1.CurrentRow.Cells["ColMaHoSo"].Value.ToString());
            parameters.Add("@ho", tboHo.Text);
            parameters.Add("@ten", tboTen.Text);
            parameters.Add("@ngaySinh", dateTimePicker1.Value);
            foreach (RadioButton item in groupBox3.Controls)
            {
                if (item.Checked)
                {
                    parameters.Add("@gioiTinh", item.Text);
                }
            }
            parameters.Add("@diaChi", tboDiaChi.Text);
            parameters.Add("@dienThoai", tboDienThoai.Text);
            parameters.Add("@email", tboEmail.Text);
            try
            {
                database.Execute(query, parameters);
                loadDgvNgoaiNgu();
                lblStatus.Text = "Thông báo : Sửa dữ liêu thành công";
            }
            catch (Exception ex)
            {
                if (ex.Message == "Trung dien thoai")
                    eprError.SetError(tboDienThoai, ex.Message);
                if (ex.Message == "Trung email")
                    eprError.SetError(tboEmail, ex.Message);
                lblStatus.Text = "Thông báo: " + ex.Message;
                MessageBox.Show(ex.Message, "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string strCommand = "EXEC spXoaHoSo @maHoSo";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@maHoSo", dataGridView1.CurrentRow.Cells["ColMaHoSo"].Value.ToString());
            try
            {
                database.Execute(strCommand, parameters);
                loadDgvNgoaiNgu();
                lblStatus.Text = "Thông báo: Xóa dữ liệu thành công";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Bao loi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Thông Báo: " + ex.Message;
            }
        }

        private void dataGridView1_RowEnter_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {

                tboHo.Text = dataGridView1.Rows[e.RowIndex].Cells["ColHo"].Value.ToString();
                tboTen.Text = dataGridView1.Rows[e.RowIndex].Cells["ColTen"].Value.ToString();
                dateTimePicker1.Text = dataGridView1.Rows[e.RowIndex].Cells["ColNgaySinh"].Value.ToString();
                foreach (RadioButton item in groupBox3.Controls)
                {
                    if (dataGridView1.Rows[e.RowIndex].Cells["ColGioiTinh"].Value.ToString() == item.Text)
                    {
                        item.Checked = true;
                    }
                }
                tboDiaChi.Text = dataGridView1.Rows[e.RowIndex].Cells["ColDiaChi"].Value.ToString();
                tboDienThoai.Text = dataGridView1.Rows[e.RowIndex].Cells["ColDienThoai"].Value.ToString();
                tboEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["ColEmail"].Value.ToString();
            }
        }
    }
}
